#ifndef CASES_INCLUDED_H
#define CASES_INCLUDED_H

using namespace std;

bool productoVectorialTest_test1();
bool productoVectorialTest_test2();
bool productoVectorialTest_test3();

bool trasponerTest_test1();
bool trasponerTest_test2();
bool trasponerTest_test3();

bool multiplicarTest_test1();
bool multiplicarTest_test2();

bool promediarTest_test1();
bool promediarTest_test2();

bool contarPicosTest_test1();
bool contarPicosTest_test2();

bool esTriangularTest_test1();
bool esTriangularTest_test2();
bool esTriangularTest_test3();
bool esTriangularTest_test4();
bool esTriangularTest_test5();

bool hayAmenazaTest_test1();
bool hayAmenazaTest_test2();
bool hayAmenazaTest_test3();
bool hayAmenazaTest_test4();
bool hayAmenazaTest_test5();

bool diferenciaDiagonalesTest_test1();
bool diferenciaDiagonalesTest_test2();
bool diferenciaDiagonalesTest_test3();
bool diferenciaDiagonalesTest_test4();
bool diferenciaDiagonalesTest_test5();
bool diferenciaDiagonalesTest_test6();


#endif //CASES_INCLUDED_H
