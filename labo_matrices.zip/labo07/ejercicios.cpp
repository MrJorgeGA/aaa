#include "ejercicios.h"

vector<vector<int> > productoVectorial(vector<int> u, vector<int> v){
	vector<vector<int> > res;
	for  (int i = 0; i < u.size(); i++) {
		res.push_back({});
		for (int j = 0; j < v.size(); j++) {
			res[i].push_back(u[i]*v[j]);
		}
	}
	return res;
}

void trasponer(vector<vector<int> > &m) {
	for (int i = 0; i < m.size(); i++) {
		for (int j = i+1 ; j < m[0].size(); j++) {
			swap (m[i][j],m[j][i]);
		}
	}
	return;
}

vector<vector<int> > multiplicar(vector<vector<int> > m1, vector<vector<int> > m2){
	vector<vector<int> > res;
	for (int i = 0; i < m1.size(); i++) {
		res.push_back({});
		for (int j = 0; j < m2[0].size(); j++) {
			res[i].push_back(0);
			for (int k = 0; k < m2.size(); k++) {
				res[i][j]+= (m1[i][k]*m2[k][j]);
			}
		}
	}
	return res;
}

vector<vector<int> > promediar(vector<vector<int> > m){
	vector<vector<int> > res;
	int n;
	int suma;
	for (int i = 0; i < m.size(); i++) {
		res.push_back({});
		for (int j = 0; j < m[0].size(); j++) {
			n = 0;
			suma = 0;
			for (int k = i-1; k <= i+1; k++) {
				if (k < 0 || k >= m.size()) continue;
				for (int l = j-1; l <= j+1; l++) {
					if (l < 0 || l >= m[0].size()) continue;
					suma += m[k][l];
					n++;
				}
			}
			res[i].push_back(suma/n);
		}
	}
	return res;
}

int contarPicos(vector<vector<int> > m){
	int res = 0;
	bool pico;
	for (int i = 0; i < m.size(); i++) {
		for (int j = 0; j < m[0].size(); j++) {
			pico = true;
			for (int k = i-1; k <= i+1 && pico; k++) {
				if (k < 0 || k >= m.size()) continue;
				for (int l = j-1; l <= j+1 && pico; l++) {
					if (l < 0 || l >= m[0].size() || (k==i && l==j)) continue;
					if (m[k][l]>= m[i][j]) pico = false;
				}
			}
			if (pico) res++;
		}
	}
	return res;
}

bool esTriangular(vector<vector<int> > m){
	return (esTriangularSuperior(m) || esTriangularInferior(m));
}

bool esTriangularSuperior (vector<vector<int> > &m) {
	bool res = true;
	for (int j = 0; j < m.size() && res; j++) {
		for (int i = j+1; i < m.size() && res; i++)
		if (m[i][j]!= 0) res = false;
	}
	return res;
}

bool esTriangularInferior (vector<vector<int> > &m) {
	bool res = true;
	for (int i = 0; i < m.size() && res; i++) {
		for (int j = i+1; j < m.size() && res; j++)
		if (m[i][j]!= 0) res = false;
	}
	return res;
}

bool hayAmenaza(vector<vector<int> > m){
	bool res = false;
	int tamano = max (m.size(), m[0].size());
	for (int i = 0; i < m.size() && !res; i++) {
		for (int j = 0; j < m[0].size() && !res; j++) {
			if (m[i][j] == 1) {
				for (int k = i+1; k < m.size() && !res; k++) {
					if (m[k][j] == 1) res = true;
				}
				for (int k = j+1; k < m[0].size() && !res; k++) {
					if (m[i][k] == 1) res = true;
				}
				for (int k = 1; k < tamano && !res; k++) {
					if (i+k < m.size() && j+k < m.size()) {
						if (m[i+k][j+k] == 1) res = true;
					}
					if (i-k >= 0 && j+k < m.size()) {
						if (m[i-k][j+k] == 1) res = true;
					}
				}
			}
		}
	}
	return res;
}

int diferenciaDiagonales(vector<vector<int> > m) {
    int res = 0;
	for (int i = 0; i < m.size(); i++) {
		res+= m[i][i];
		res-= m[i][m.size()-1-i];
	}
	res = abs(res);
    return res;
}