#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

void insertar(vector<int> &arr, int i) {
	for (int j = i; j > 0 && arr[j] > arr[j-1]; j--) {
		swap (arr[j], arr[j-1]);
	}
}

void insertionSort(vector< int > &arr){
	for (int i = 0; i < arr.size(); i++) {
		insertar (arr, i);
	}
}

int indiceMaximaPosicion (vector <int> &arr, int c) {
	for (int i = c+1; i < arr.size(); i++) {
		if (arr[i] > arr[c]) c = i;
	}
	return c;
}

void selectionSort(vector< int > &arr){
	for (int i = 0; i < arr.size(); i++) {
		swap(arr[i],arr[indiceMaximaPosicion(arr, i)]);
	}
}

void countSort(vector<int>& arr)
{
    int max = *max_element(arr.begin(), arr.end());
    int min = *min_element(arr.begin(), arr.end());
    int range = max - min + 1;
  
    vector<int> count(range), output(arr.size());
    for (int i = 0; i < arr.size(); i++)
        count[arr[i] - min]++;
  
    for (int i = 1; i < count.size(); i++)
        count[i] += count[i - 1];
  
    for (int i = arr.size() - 1; i >= 0; i--) {
        output[count[arr[i] - min] - 1] = arr[i];
        count[arr[i] - min]--;
    }
  
    for (int i = 0; i < arr.size(); i++)
        arr[i] = output[i];
}


void ordenar(vector<int> &items){
	countSort(items);
	reverse(items.begin(),items.end());
}


int bestFit(int W, vector<int> &items){
	multiset<int> restos;
	for(int i=0; i<(int)items.size(); ++i){
		restos.insert(W);
	}
	int res = 0;
	for(int i=0; i<(int)items.size(); ++i){
		multiset<int>::iterator it = restos.lower_bound(items[i]);
		int restoAct = *it;
		if(restoAct==W){
			res++;
		}
		restoAct -= items[i];
		restos.erase(it);
		restos.insert(restoAct);
	}
	return res;
}

int main(){
	int N, W, aux;

	//Se levantan los items y la capacidad del contenedor
	cout << "Se levantan los items y la capacidad del contenedor";
	ifstream bpp("BPP4.in");
	bpp >> N >> W;
	vector<int> items;
	for(int i=0; i<N; ++i){
		bpp >> aux;
		items.push_back(aux);
	}
	bpp.close();
	//Se corre best-fit
	double t0 = clock();
	int cant1 = bestFit(W, items);
	double t1 = clock();
	double tiempo = (t1-t0)/CLOCKS_PER_SEC;
	cout << "Con la idea bestFit, se consigue una asignacion con " << cant1 << " contenedores en " << tiempo << " segundos" << endl;

	//Se ordenan los items
	t0 = clock();
	ordenar(items);
	//Se corre best-fit-decreasing
	int cant2 = bestFit(W, items);
	t1 = clock();
	tiempo = (t1-t0)/CLOCKS_PER_SEC;
	cout << "Con la idea bestFitDecreasing, se consigue una asignacion con " << cant2 << " contenedoresen " << tiempo << " segundos" << endl;

	return 0;
}
