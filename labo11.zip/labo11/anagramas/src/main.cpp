#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "anagramas.h"
#include <algorithm>
#include <math.h>
using namespace std;

void curarPalabra(string &palabra) {
    string aux = {};
    for (int i = 0; i < palabra.size(); i++) {
        if (isspace(palabra[i]));
        else aux.push_back(palabra[i]);
    }
    palabra = aux;
}

int main(){
    string palabra, palabra2;
    cout << "Ingrese una palabra en ingles con letras en minuscula: ";
    cin >> palabra;

    ifstream dicci ("ingles.dic");
    vector<string> listaPalabras;
    string word;
    while(getline(dicci, word)){
        curarPalabra(word);
        listaPalabras.push_back(word);
    }
    int cantidadAnagrama = 0;
    for (int i = 0; i < listaPalabras.size(); i++)
    {
        if (esAnagrama(listaPalabras[i], palabra)) {
            cout << "Son anagramas: " << listaPalabras[i] << " y " << palabra << endl;
            cantidadAnagrama++;
        }
    }
    cout << "La cantidad de anagramas es: " << cantidadAnagrama << endl;
    return 0;
}

bool esAnagrama(string p1, string p2){
    // CAMBIAR AQUI QUE IMPLEMENTACION USAR
    /* string aux = {};
    for (int i = 0; i < p1.size(); i++) {
        if (isspace(p1[i]));
        else aux.push_back(p1[i]);
    }
    p1 = aux; */
    if (p1 == p2) return false;
    return esAnagrama1(p1,p2);
}

bool esAnagrama1(string p1, string p2){
    //devuelve true sii p1 es anagrama de p2
    //esta versión usa ordenar
    ordenarString(p1);
    ordenarString(p2);
    return p1 == p2;
}

bool esAnagrama2(string p1, string p2){
    //COMPLETAR
    //devuelve true sii p1 es anagrama de p2
    //esta versión usa el mapeo de letras a números primos. Utilizar charToPrimo()
    if (p1.size()!=p2.size()) return false;
    int n1 = 1;
    int n2 = 1;
    for (int i = 0; i < p1.size(); i++) {
        n1*=charToPrimo(p1[i]);
        n2*=charToPrimo(p2[i]);
    }
	return n1==n2;
}

void ordenarString(string &palabra){
    //COMPLETAR
    //Asumir que palabra solo contiene letras minusculas de a-z (sin enie). Implementar cualquier algoritmo
    vector <int> contador(26);
    for (int i = 0; i < palabra.size(); i++) {
        contador[palabra[i]-'a']++;
    }
    string aux;
    for (int i = 0; i < contador.size(); i++) {
        while (contador[i]>0) {
            aux.push_back(char('a'+i));
            contador[i]--;
        } 
    }
    palabra = aux;
    return;
}

bool esPrimo (int n) {
    int i;
    for (i = 2; i < sqrt(n) && n%i!=0; i++);
    return i >= sqrt(n);
}

int eneSimoPrimo (int n) {
    int i=1;
    if (n == 0) return 2;
    else while (n>0) {
        i+=2;
        if (esPrimo(i)) n--;
    }
    return i;
}

int charToPrimo(char c){
    //COMPLETAR
    //Dado una letra minuscula de a-z (sin enie) devolver el numero primo correspondiente.
	return eneSimoPrimo(posicionEnAlfabeto(c));
}

int posicionEnAlfabeto(char c){
    return c - 'a';
}
